/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

import java.util.ArrayList;

/**
 *
 * @author Ali Haydar
 */
public class Player {

    ArrayList<Territory> territories;
    int playerID;
    int soldierCount;
    boolean isTurn;
    boolean isItReady;
    String color;

    public Player(int playerID) {
        this.playerID = playerID;
        this.territories = new ArrayList<>();
        this.isTurn = false;
        this.isItReady = false;
        this.color = generateRandomColor();
    }

    // Renk Getter ve Setter
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean getIsTurn() {
        return isTurn;
    }

    // Rastgele renk üretme metodu
    public String generateRandomColor() {
        // Renk listesi tanımla
        String[] colors = {
            "red", "blue", "green", "yellow", "orange", "pink", "brown", "gray", "cyan", "magenta", "violet",
            "indigo", "lightblue", "lightgreen", "lime", "teal", "maroon", "navy", "gold", "silver", "crimson", "chartreuse",
            "salmon", "turquoise", "peach", "lavender", "beige", "khaki", "plum", "orchid", "coral", "aqua", "#FF6347", "#8A2BE2",
            "#7FFF00", "#D2691E", "#FF1493", "#B8860B", "#FF4500", "#2E8B57", "#D3D3D3", "#B22222", "#5F9EA0", "#8B0000"
        };

        // Rastgele bir renk seç
        int randomIndex = (int) (Math.random() * colors.length);
        return colors[randomIndex];
    }

    public int getPlayerID() {
        return playerID;
    }

    public int getSoldierCount() {
        return soldierCount;
    }

    public void setSoldierCount(int soldierCount) {
        this.soldierCount = soldierCount;
    }

    public void setIsTurn(boolean isTurn) {
        this.isTurn = isTurn;
    }

    public void setIsItReady(boolean isItReady) {
        this.isItReady = isItReady;
    }

    public boolean getIsItReady() {
        return this.isItReady;
    }

}
