/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

import static java.lang.Math.floor;
import static java.lang.Math.max;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Ali Haydar
 */
public class Game {

    ArrayList<Player> players;
    ArrayList<Territory> territories;
    int index;
    boolean isItStarted;
    ArrayList<String> messages = new ArrayList<>();
    
    

    public Game() {
        players = new ArrayList<>();
        territories = new ArrayList<>();
        index = 0;
        isItStarted = false;
        
        Territory t1 = new Territory("A bölgesi",1);
        Territory t2 = new Territory("B bölgesi",2);
        Territory t3 = new Territory("C bölgesi",3);
        Territory t4 = new Territory("D bölgesi",4);
        Territory t5 = new Territory("E bölgesi",5);
        Territory t6 = new Territory("F bölgesi",6);
        Territory t7 = new Territory("G bölgesi",7);
        Territory t8 = new Territory("H bölgesi",8);
        Territory t9 = new Territory("I bölgesi",9);
        Territory t10 = new Territory("J bölgesi",10);
        Territory t11 = new Territory("K bölgesi",11);
        Territory t12 = new Territory("L bölgesi",12);
        Territory t13 = new Territory("M bölgesi",13);
        Territory t14 = new Territory("N bölgesi",14);
        Territory t15 = new Territory("O bölgesi",15);
        Territory t16 = new Territory("P bölgesi",16);
        Territory t17 = new Territory("R bölgesi",17);
        Territory t18 = new Territory("S bölgesi",18);
        Territory t19 = new Territory("T bölgesi",19);
        Territory t20 = new Territory("U bölgesi",20);
        Territory t21 = new Territory("Y bölgesi",21);
        Territory t22 = new Territory("X bölgesi",22);
        Territory t23 = new Territory("W bölgesi",23);
        
        this.territories.add(t1);
        this.territories.add(t2);
        this.territories.add(t3);
        this.territories.add(t4);
        this.territories.add(t5);
        this.territories.add(t6);
        this.territories.add(t7);
        this.territories.add(t8);
        this.territories.add(t9);
        this.territories.add(t10);
        this.territories.add(t11);
        this.territories.add(t12);
        this.territories.add(t13);
        this.territories.add(t14);
        this.territories.add(t15);
        this.territories.add(t16);
        this.territories.add(t17);
        this.territories.add(t18);
        this.territories.add(t19);
        this.territories.add(t20);
        this.territories.add(t21);
        this.territories.add(t22);
        this.territories.add(t23);
        
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }
    

    public ArrayList<Territory> getTerritories() {
        return territories;
    }
    
    public ArrayList<String> getMessages(){
        return messages;
    }
    public void setMessages(ArrayList<String> messages){
        this.messages = messages;
    }
    
    public boolean getIsItStarted(){
        return isItStarted;
    }

    public void setIsItStarted(boolean isItStarted) {
        this.isItStarted = isItStarted;
    }
    
    public void isGameStarted(){
        boolean bool = true;
        
        for (Player player : this.getPlayers()) {
            if(!player.getIsItReady()){
                bool = false;
                break;
            }   
        }
        
       this.isItStarted = (bool && this.getPlayers().size() >=2) ;
    }
    
    

    public JSONObject toJSON() {
        JSONObject json = new JSONObject();

        JSONArray playersArray = new JSONArray();
        for (Player p : players) {
            JSONObject pJson = new JSONObject();
            pJson.put("id", p.getPlayerID());
            pJson.put("color", p.getColor());
            playersArray.put(pJson);
        }
        json.put("players", playersArray);

        System.out.println("GAME KONTROL : " + json);

        return json;

    }

    public JSONArray toTerritoryJSONArray() {
        JSONArray arr = new JSONArray();
        for (Territory t : territories) {
            arr.put(t.toJSON());
        }
        return arr;
    }

    //PLAYER FUNCTIONS
    public JSONObject sendSoldierPlayer(Territory t, int soldier, Player p) {
        if (p.territories.contains(t)) {
            if (p.soldierCount < soldier) {
                return new JSONObject().put("bool", false)
                        .put("data", "Asker sayisi yetersiz");
            } else {
                t.soldierCount += soldier;
                p.soldierCount -= soldier;
                return new JSONObject().put("bool", true)
                        .put("data", "Asker gonderimi basarili");
            }
        } else {
            return new JSONObject().put("bool", false)
                    .put("data", "Bolge oyuncuya ait degil.");
        }
    }

    public JSONObject takeSoldierFromTerritory(Territory t, int soldier, Player p) {

        if (p.territories.contains(t)) {
            if (soldier > p.soldierCount) {
                return new JSONObject().put("bool", false)
                        .put("data", "Asker sayisi yetersiz");
            } else {
                t.soldierCount -= soldier;
                p.soldierCount += soldier;
                return new JSONObject().put("bool", true)
                        .put("data", "İslem basarili");
            }
        } else {
            return new JSONObject().put("bool", false)
                    .put("data", "Bolge oyuncuya ait degil");
        }
    }

    //TERRITORY FUNCKTIONS
    public void setOwnerTerritory(Player p, Territory t) {
        t.owner = p;
        t.setColor(p.getColor());
        
        for (Player player : this.players) {
            if(player.territories.contains(t)){
                player.territories.remove(t);
                break;
            }
        }
        p.territories.add(t);
    }

    public int calculateDiceCount(boolean isAttacker, int soldierCount) {
        if (isAttacker) {
            if (soldierCount >= 4) {
                return 3;
            } else if (soldierCount == 3) {
                return 2;
            } else if (soldierCount == 2) {
                return 1;
            } else {
                return 0;
            }
        } else {
            if (soldierCount >= 2) {
                return 2;
            } else if (soldierCount == 1) {
                return 1;
            } else {
                return 0;
            }

        }
    }

    public void addTerritory(Territory t) {
        this.territories.add(t);
    }

    public void shuffleTerritories() {
        Collections.shuffle(this.territories);
        int playerIndex = 0;

        for (Territory t : this.territories) {
            Player p = players.get(playerIndex);
            this.setOwnerTerritory(p, t);
            p.territories.add(t);

            //System.out.println(p.territories);
            t.soldierCount = 1;
            p.soldierCount -= 1;

            playerIndex = (playerIndex + 1) % players.size();
        }
    }

    public void assignSoldierCount() {
        for (Player player : players) {
            player.soldierCount = (int) Math.max(3, Math.floor(player.territories.size() / 3)) < 3 ? (int) Math.max(3, Math.floor(player.territories.size() / 3)) : 3;
        }
    }

    public JSONArray soldierCountToJson() {
        JSONArray arr = new JSONArray();

        for (Player player : this.players) {
            arr.put(new JSONObject().put("id", player.getPlayerID()).put("soldierCount", player.getSoldierCount()));
        }

        return arr;
    }

    public JSONArray territoriesToJson() {
        JSONArray arr = new JSONArray();

        for (Territory territory : this.territories) {
            arr.put(new JSONObject().put("id", territory.getId()).put("soldierCount", territory.getOwner().getPlayerID()));
        }

        return arr;
    }

    public void start() {
        players.get(index).isTurn = true;

        if (index != players.size() - 1) {
            index++;
        } else {
            index = 0;
        }
        
        
    }

    public void nextTurn() {
        players.get(index - 1).isTurn = false;
        players.get(index).isTurn = true;

        if (index != players.size() - 1) {
            index++;
        } else {
            index = 0;
        }
    }

    public void addPlayer(Player p) {
        this.players.add(p);
    }

    /* public boolean battle(Territory attacker, Territory defender) {

        int attackerDiceCount = calculateDiceCount(true, attacker.soldierCount);
        int defenderDiceCount = calculateDiceCount(false, defender.soldierCount);

        int[] attackerDices = new int[attackerDiceCount];
        int[] defenderDices = new int[defenderDiceCount];

        for (int i = 0; i < attackerDices.length; i++) {
            attackerDices[i] = (int) (Math.random() * 6) + 1;
        }
        for (int i = 0; i < defenderDices.length; i++) {
            defenderDices[i] = (int) (Math.random() * 6) + 1;
        }

        Arrays.sort(attackerDices);

        for (int i = 0; i < attackerDices.length / 2; i++) {
            int temp = attackerDices[i];
            attackerDices[i] = attackerDices[attackerDices.length - 1 - i];
            attackerDices[attackerDices.length - 1 - i] = temp;
        }

        Arrays.sort(defenderDices);

        for (int i = 0; i < defenderDices.length / 2; i++) {
            int temp = defenderDices[i];
            defenderDices[i] = defenderDices[defenderDices.length - 1 - i];
            defenderDices[defenderDices.length - 1 - i] = temp;
        }

        int compareCount = attackerDiceCount <= defenderDiceCount ? attackerDiceCount : defenderDiceCount;

        for (int i = 0; i < compareCount; i++) {
            if (attackerDices[i] > defenderDices[i]) {
                defender.soldierCount--;
                defender.owner.soldierCount--;
            } else {
                attacker.soldierCount--;
                defender.owner.soldierCount--;
            }
        }

        if (defender.soldierCount <= 0) {
            defender.owner.territories.remove(defender);
            setOwnerTerritory(attacker.owner, defender);
            return true;
        } else if (attacker.soldierCount == 0) {
            return false;
        }

        return false;
    }*/
    public JSONArray battleJSON(Territory attacker, Territory defender) {
        JSONArray result = new JSONArray();

        int attackerDiceCount = calculateDiceCount(true, attacker.soldierCount);
        int defenderDiceCount = calculateDiceCount(false, defender.soldierCount);

        int[] attackerDices = new int[attackerDiceCount];
        int[] defenderDices = new int[defenderDiceCount];

        for (int i = 0; i < attackerDices.length; i++) {
            attackerDices[i] = (int) (Math.random() * 6) + 1;
        }
        for (int i = 0; i < defenderDices.length; i++) {
            defenderDices[i] = (int) (Math.random() * 6) + 1;
        }

        Arrays.sort(attackerDices);
        reverse(attackerDices);

        Arrays.sort(defenderDices);
        reverse(defenderDices);

        // Zarları ekle
        JSONObject attackerObj = new JSONObject();
        attackerObj.put("attackerDices", attackerDices);
        result.put(attackerObj);

        JSONObject defenderObj = new JSONObject();
        defenderObj.put("defenderDices", defenderDices);
        result.put(defenderObj);

        int compareCount = Math.min(attackerDiceCount, defenderDiceCount);

        for (int i = 0; i < compareCount; i++) {
            if (attackerDices[i] > defenderDices[i]) {
                defender.soldierCount--;
                defender.owner.soldierCount--;
            } else {
                attacker.soldierCount--;
                defender.owner.soldierCount--;
            }
        }

        boolean attackerWon = false;

        if (defender.soldierCount <= 0) {
            defender.owner.territories.remove(defender);
            setOwnerTerritory(attacker.owner, defender);
            attackerWon = true;
        }

        // Sonuç objesi
        JSONObject resultObj = new JSONObject();
        resultObj.put("winner", attackerWon);
        result.put(resultObj);

        return result;
    }

    public void reverse(int[] array) {
        for (int i = 0; i < array.length / 2; i++) {
            int temp = array[i];
            array[i] = array[array.length - 1 - i];
            array[array.length - 1 - i] = temp;
        }
    }

    public static void main(String[] args) {
        Game g = new Game();

        Player p1 = new Player(10);
        Player p2 = new Player(1);
        Player p3 = new Player(54);

        Territory t1 = new Territory("A bölgesi");
        Territory t2 = new Territory("B bölgesi");
        Territory t3 = new Territory("B bölgesi");
        Territory t4 = new Territory("B bölgesi");

        g.addTerritory(t1);
        g.addTerritory(t2);
        g.addTerritory(t3);
        g.addTerritory(t4);

        g.addPlayer(p1);
        g.addPlayer(p2);
        g.addPlayer(p3);

        g.shuffleTerritories();
        g.assignSoldierCount();

        g.sendSoldierPlayer(t1, 3, p1);

        System.out.println(g.battleJSON(t1, t2));
        System.out.println(g.soldierCountToJson());
        System.out.println(g.getTerritories().get(3).getOwner().getPlayerID());

    }

}
